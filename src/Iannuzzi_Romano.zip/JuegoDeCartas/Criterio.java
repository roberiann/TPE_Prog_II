package JuegoDeCartas;

public abstract class Criterio {
    public abstract boolean cumple(Card card);
}
