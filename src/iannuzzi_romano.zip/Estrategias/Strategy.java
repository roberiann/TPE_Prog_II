package Estrategias;

import JuegoDeCartas.Card;

public abstract class Strategy {
	
	public abstract String getAttribute(Card card); 
}
